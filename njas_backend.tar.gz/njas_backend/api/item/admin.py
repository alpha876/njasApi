from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Units)
admin.site.register(Ingredient)
admin.site.register(Recipe)
admin.site.register(RecipeCategory)
admin.site.register(Category)
admin.site.register(IngredientList)
admin.site.register(CropType)
admin.site.register(OrderItem)
admin.site.register(Product)