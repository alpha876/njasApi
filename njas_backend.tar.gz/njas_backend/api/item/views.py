from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
from .models import Ingredient, Recipe, Product




def home(request):
    ingredient =Ingredient.objects.all()
    context = {
        "title":'Home Page',
        "ingredient":ingredient
    }
    return render(request, "item/home.html", context)
class HomeView(TemplateView):
    model =Ingredient
    template_name = "item/home.html"
    context_object_name = "ingredient"

class SaladsListView(ListView):
    model = Product
    template_name = 'item/salads.html'
    context_object_name = 'salad'



class MealsListView(ListView):
    model = Product
    template_name = 'item/meals.html'
    context_object_name = 'meals'


class RecipesListView(ListView):
    model = Recipe
    template_name = 'item/recipes.html'
    context_object_name = 'recipes'


class GroceriesListView(ListView):
    model = Ingredient
    template_name = 'item/groceries.html'
    context_object_name = 'groceries'
