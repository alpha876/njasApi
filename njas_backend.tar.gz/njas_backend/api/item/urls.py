from django.urls import path
from .views import home, HomeView,  SaladsListView, MealsListView, RecipesListView, GroceriesListView

urlpatterns = [
    path('', home, name='home'),
    path('salads/', SaladsListView.as_view(), name='salads'),
    path('groceries/', GroceriesListView.as_view(), name='groceries'),
    path('meals/', MealsListView.as_view(), name='meals'),
    path('recipes/', RecipesListView.as_view(), name='recipes'),
]
